# HELPER
나만의 운동 메이트 찾기 서비스

# PROJECT 목표
- JPA 활용 및 이해 (DB와의 상호작용 측면에서)
- Spring Boot 흐름과 mvc구조의 이해

-> 그리고 이들을 활용한 CRUD 기능 구현
